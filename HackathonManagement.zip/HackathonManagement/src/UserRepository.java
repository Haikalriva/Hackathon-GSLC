
public class UserRepository {

	public boolean insert(String[] strings) {
		// TODO Auto-generated method stub
		return false;
	}

}
