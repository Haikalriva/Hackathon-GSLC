import java.util.Scanner;

		public class MenuProgram {
		    public static void main(String[] args) {
		        Scanner scanner = new Scanner(System.in);
		        UserRepository userRepository = new UserRepository();
		        TeamRepository teamRepository = new TeamRepository();

		        while (true) {
		            System.out.println("\nMenu Utama");
		            System.out.println("1. Insert Data");
		            System.out.println("2. Show");
		            System.out.println("3. Exit");

		            System.out.print("Choose an option: ");
		            int choice = scanner.nextInt();
		            scanner.nextLine(); // Consume the newline character

		            switch (choice) {
		                case 1:
		                    insertDataMenu(userRepository, teamRepository, scanner);
		                    break;
		                case 2:
		                    showMenu(userRepository, teamRepository, scanner);
		                    break;
		                case 3:
		                    System.out.println("Exiting program. Goodbye!");
		                    System.exit(0);
		                    break;
		                default:
		                    System.out.println("Invalid option. Please choose again.");
		            }
		        }
		    }

		    private static void insertDataMenu(UserRepository userRepository, TeamRepository teamRepository, Scanner scanner) {
		        System.out.println("\nInsert Data");
		        System.out.print("Which table to insert? 1. User, 2. Team: ");
		        int tableChoice = scanner.nextInt();
		        scanner.nextLine(); // Consume the newline character

		        if (tableChoice == 1) {
		            System.out.print("Add name: ");
		            String name = scanner.nextLine();

		            System.out.print("Add nim: ");
		            String nim = scanner.nextLine();

		            System.out.print("Add team: ");
		            String teamName = scanner.nextLine();

		            if (userRepository.insert(new String[]{name, nim, teamName})) {
		                System.out.println("User created!");
		            } else {
		                System.out.println("Error: Team Full");
		            }
		        } else if (tableChoice == 2) {
		            // Similar steps for inserting into the Team table
		            // ...
		        } else {
		            System.out.println("Invalid option. Returning to the main menu.");
		        }
		    }

		    private static void showMenu(UserRepository userRepository, TeamRepository teamRepository, Scanner scanner) {
		        System.out.println("\nShow");
		        System.out.print("Which table to show? 1. User, 2. Team: ");
		        int tableChoice = scanner.nextInt();
		        scanner.nextLine(); // Consume the newline character

		        System.out.print("Want to filter by condition? 1. Yes, 2. No: ");
		        int filterChoice = scanner.nextInt();
		        scanner.nextLine(); // Consume the newline character

		        if (filterChoice == 1) {
		            System.out.print("Add condition, separate by semicolon: ");
		            String condition = scanner.nextLine();
		            // Parse the condition and perform the query
		            // ...
		        } else if (filterChoice == 2) {
		            // Show all data without conditions
		            // ...
		        } else {
		            System.out.println("Invalid option. Returning to the main menu.");
		        }
		    }
		}

	